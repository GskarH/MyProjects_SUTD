#!/usr/bin/env python
# Skeleton for Security Tools Lab 1 - Simple ciphers
# Student ID: 1006523
# StudentName: Gowtham Baskar

import binascii as b
import string
import codecs
import requests
import json
import hashlib
import argparse
from math import ceil



def xorString(s1, s2):
    """
        XOR two strings with each other, return result as string
    """
    rval = [ord(a) ^ ord(b) for a, b in zip(s1, s2)]
    return ''.join([chr(r) for r in rval])


def resolvePlainChallenge():
    """
        Solution of plain challenge
    """
    url = "http://{}:{}/".format(IP, PORT)
    headers = {'Content-Type': 'application/json'}

    r = requests.get(url + 'challenges/plain')
    data = r.json()
    print("[DEBUG] Obtained challenge ciphertext: %s with len %d" % (data['challenge'], len(data['challenge'])))

    # TODO: Add a solution here (conversion from hex to ascii will reveal that the result is in a human readable format)
    a = data['challenge'][2:]
    s = bytearray.fromhex(a).decode()

    payload = {'cookie': data['cookie'], 'solution': s}
    print("[DEBUG] Submitted solution is:")
    print(json.dumps(payload, indent=4, separators=(',', ': ')))

    r = requests.post(url + 'solutions/plain', headers=headers, data=json.dumps(payload))
    print("[DEBUG] Obtained response: %s" % r.text)


def resolveCaesarChallenge():
    """
        Solution of caesar challenge
    """

    a = ""
    for i in range(128):
        a = a + chr(i)
    alphabet = a
    for i in range(128):
        try:
            url = "http://{}:{}/".format(IP, PORT)
            headers = {'Content-Type': 'application/json'}

            r = requests.get(url + 'challenges/caesar')
            data = r.json()
            print("[DEBUG] Obtained challenge ciphertext: %s with len %d" % (data['challenge'], len(data['challenge'])))

            # TODO: Add a solution here (conversion from hex to ascii will reveal that the result is in a human readable format)
            s = data['challenge'][2:]
            s = b.unhexlify(s)
            s = s.decode("ASCII")
            solution = s

            print("Solution before shifting",s, len(s))
            for i in range(128):
                shift = i
                shift %= 128
                shifted = alphabet[shift:] + alphabet[:shift]
                table = str.maketrans(alphabet, shifted)
                encrypted = solution.translate(table)
                solution = encrypted
                payload = {'cookie': data['cookie'], 'solution': encrypted}
                print("[DEBUG] Submitted solution is:")
                print(json.dumps(payload, indent=4, separators=(',', ': ')))
                r = requests.post(url + 'solutions/caesar', headers=headers, data=json.dumps(payload))
                print("[DEBUG] Obtained response: %s" % r.text)
                if r.text.__contains__("Your answer is correct"):
                    break
            if r.text.__contains__("Your answer is correct"):
                break
        except:
            continue

def resolvesubstitutionChallenge():
    """
        Solution of substitution challenge
    """
    url = "http://{}:{}/".format(IP, PORT)
    headers = {'Content-Type': 'application/json'}

    r = requests.get(url + 'challenges/substitution')
    data = r.json()
    # print("[DEBUG] Obtained challenge ciphertext: %s with len %d" % (data['challenge'], len(data['challenge'])))

    # TODO: Add a solution here (conversion from hex to ascii will reveal that the result is in a human readable format)
    s = data['challenge'][2:]
    s = b.unhexlify(s)
    #print(s)
    #Converto to Byte Array

    bytesAr = []
    for num in s:
        count = ceil(num.bit_length() / 8)
        bytes = num.to_bytes(count, 'big')
        bytesAr.extend('{:02X}'.format(x) for x in bytes)
    #print(bytesAr)
    #Frequency Analysis
    '''
    encrypted_message = bytesAr
    stored_letters = {}
    for char in encrypted_message:
        if char not in stored_letters:
            stored_letters[char] = 1
        else:
            stored_letters[char] += 1

    print(stored_letters,'\n', len(stored_letters))
    print(len(bytesAr))
    '''
    #Alternative
    replacements = { bytesAr[1] : 'a',bytesAr[2] : 'b', bytesAr[3] : 'c',bytesAr[4] : 'l', bytesAr[5] : 'g',bytesAr[6] : 'f',
                     bytesAr[7] : 'g', bytesAr[8] : 'h',bytesAr[9] : 'd', bytesAr[10] : '-',bytesAr[11] : 'k', bytesAr[12] : 'l',bytesAr[13] : 'm',
                     bytesAr[14] : ' ', bytesAr[15] : 'o',bytesAr[16] : 'p', bytesAr[17] : 'c',bytesAr[18] : 'r', bytesAr[19] : 's',bytesAr[20] : 'u',
                     bytesAr[21] : 'p', bytesAr[22] : 'o',bytesAr[23] : 'n', bytesAr[24] : 'x',bytesAr[25] : 'a', bytesAr[26] : 'z',bytesAr[27] : '!',
                     bytesAr[28] : 'i', bytesAr[29] : 'm',bytesAr[30] : 'w', bytesAr[31] : '',bytesAr[32] : 't', bytesAr[33] : 'h',bytesAr[34] : '/n',
                     bytesAr[35]: 'r', bytesAr[36]: 'e', '09': 'g'}
    # alphabet = '''abcdefghijklmnopqrstuvwxyz!"'+,-.:; '''

    replacer = replacements.get
    new_byteArr = [replacer(n, n) for n in bytesAr]
    print(new_byteArr)
    # new_byteArr = ['l', 'i', 't', 't', 'l', 'e', '', 'r', 'e', 'd', '-', 'c', 'a', 'p', ' ', 'o', 'n', 'c', 'e', '', 'u', 'p', 'o', 'n', '', 'a', '', 't', 'i', 'm', 'e', '', 't', 'h', 'e', 'r', 'e', '', 'w', 'a', 's', '', 'a', '', 'd', 'e', 'a', 'r', '', 'l', 'i', 't', 't', 'l', 'e', '', 'G', 'i', 'r', 'l', '', 'w', 'h', 'o', '', 'w', 'a', 's', '', 'l', 'o', 'V', 'e', 'd', ' ', 'b', 'y', '', 'e', 'V', 'e', 'r', 'y', '', 'o', 'n', 'e', '', 'w', 'h', 'o', '', 'l', 'o', 'o', 'k', 'e', 'd', '', 'a', 't', '', 'h', 'e', 'r', ':', '', 'b', 't', 't', '', 'm', 'o', 's', 't', '', 'o', 'f', '', 'a', 'l', 'l', '', 'b', 'y', '', 'h', 'e', 'r', ' ', 'G', 'r', 'a', 'n', 'd', 'm', 'o', 't', 'h', 'e', 'r', ':', '', 'a', 'n', 'd', '', 't', 'h', 'e', 'r', 'e', '', 'w', 'a', 's', '', 'n', 'o', 't', 'h', 'i', 'n', 'G', '', 't', 'h', 'a', 't', '', 's', 'h', 'e', '', 'w', 'o', 't', 'l', 'd', '', 'n', 'o', 't', '', 'h', 'a', 'V', 'e', ' ', 'G', 'i', 'V', 'e', 'n', '', 't', 'o', '', 't', 'h', 'e', '', 'c', 'h', 'i', 'l', 'd', '.', '', '', 'o', 'n', 'c', 'e', '', 's', 'h', 'e', '', 'G', 'a', 'V', 'e', '', 'h', 'e', 'r', '', 'a', '', 'l', 'i', 't', 't', 'l', 'e', '', 'c', 'a', 'p', '', 'o', 'f', '', 'r', 'e', 'd', ' ', 'V', 'e', 'l', 'V', 'e', 't', ':', '', 'w', 'h', 'i', 'c', 'h', '', 's', 't', 'i', 't', 'e', 'd', '', 'h', 'e', 'r', '', 's', 'o', '', 'w', 'e', 'l', 'l', '', 't', 'h', 'a', 't', '', 's', 'h', 'e', '', 'w', 'o', 't', 'l', 'd', '', 'n', 'e', 'V', 'e', 'r', '', 'w', 'e', 'a', 'r', ' ', 'a', 'n', 'y', 't', 'h', 'i', 'n', 'G', '', 'e', 'l', 's', 'e', '.', '', '', 's', 'o', '', 's', 'h', 'e', '', 'w', 'a', 's', '', 'a', 'l', 'w', 'a', 'y', 's', '', 'c', 'a', 'l', 'l', 'e', 'd', '', 'l', 'i', 't', 't', 'l', 'e', '', 'r', 'e', 'd', '-', 'c', 'a', 'p', '.', ' ', 'o', 'n', 'e', '', 'd', 'a', 'y', '', 'h', 'e', 'r', '', 'm', 'o', 't', 'h', 'e', 'r', '', 's', 'a', 'i', 'd', '', 't', 'o', '', 'h', 'e', 'r', ':', '', 'c', 'o', 'm', 'e', ':', '', 'l', 'i', 't', 't', 'l', 'e', '', 'r', 'e', 'd', '-', 'c', 'a', 'p', ':', '', 'h', 'e', 'r', 'e', ' ', 'i', 's', '', 'a', '', 'p', 'i', 'e', 'c', 'e', '', 'o', 'f', '', 'c', 'a', 'k', 'e', '', 'a', 'n', 'd', '', 'a', '', 'b', 'o', 't', 't', 'l', 'e', '', 'o', 'f', '', 'w', 'i', 'n', 'e', '.', '', '', 't', 'a', 'k', 'e', '', 't', 'h', 'e', 'm', '', 't', 'o', '', 'y', 'o', 't', 'r', ' ', 'G', 'r', 'a', 'n', 'd', 'm', 'o', 't', 'h', 'e', 'r', ':', '', 's', 'h', 'e', '', 'i', 's', '', 'i', 'l', 'l', '', 'a', 'n', 'd', '', 'w', 'e', 'a', 'k', ':', '', 'a', 'n', 'd', '', 't', 'h', 'e', 'y', '', 'w', 'i', 'l', 'l', '', 'd', 'o', '', 'h', 'e', 'r', '', 'G', 'o', 'o', 'd', '.', ' ', 's', 'e', 't', '', 'o', 't', 't', '', 'b', 'e', 'f', 'o', 'r', 'e', '', 'i', 't', '', 'G', 'e', 't', 's', '', 'h', 'o', 't', ':', '', 'a', 'n', 'd', '', 'w', 'h', 'e', 'n', '', 'y', 'o', 't', '', 'a', 'r', 'e', '', 'G', 'o', 'i', 'n', 'G', ':', '', 'w', 'a', 'l', 'k', ' ', 'n', 'i', 'c', 'e', 'l', 'y', '', 'a', 'n', 'd', '', 'Q', 't', 'i', 'e', 't', 'l', 'y', '', 'a', 'n', 'd', '', 'd', 'o', '', 'n', 'o', 't', '', 'r', 't', 'n', '', 'o', 'f', 'f', '', 't', 'h', 'e', '', 'p', 'a', 't', 'h', ':', '', 'o', 'r', '', 'y', 'o', 't', '', 'm', 'a', 'y', ' ', 'f', 'a', 'l', 'l', '', 'a', 'n', 'd', '', 'b', 'r', 'e', 'a', 'k', '', 't', 'h', 'e', '', 'b', 'o', 't', 't', 'l', 'e', ':', '', 'a', 'n', 'd', '', 't', 'h', 'e', 'n', '', 'y', 'o', 't', 'r', '', 'G', 'r', 'a', 'n', 'd', 'm', 'o', 't', 'h', 'e', 'r', '', 'w', 'i', 'l', 'l', ' ', 'G', 'e', 't', '', 'n', 'o', 't', 'h', 'i', 'n', 'G', '.', '', '', 'a', 'n', 'd', '', 'w', 'h', 'e', 'n', '', 'y', 'o', 't', '', 'G', 'o', '', 'i', 'n', 't', 'o', '', 'h', 'e', 'r', '', 'r', 'o', 'o', 'm', ':', '', 'd', 'o', 'n', '‘', 't', '', 'f', 'o', 'r', 'G', 'e', 't', ' ', 't', 'o', '', 's', 'a', 'y', ':', '', 'G', 'o', 'o', 'd', '-', 'm', 'o', 'r', 'n', 'i', 'n', 'G', ':', '', 'a', 'n', 'd', '', 'd', 'o', 'n', '‘', 't', '', 'p', 'e', 'e', 'p', '', 'i', 'n', 't', 'o', '', 'e', 'V', 'e', 'r', 'y', '', 'c', 'o', 'r', 'n', 'e', 'r', '', 'b', 'e', 'f', 'o', 'r', 'e', ' ', 'y', 'o', 't', '', 'd', 'o', '', 'i', 't', '.', ' ', 'i', '', 'w', 'i', 'l', 'l', '', 't', 'a', 'k', 'e', '', 'G', 'r', 'e', 'a', 't', '', 'c', 'a', 'r', 'e', ':', '', 's', 'a', 'i', 'd', '', 'l', 'i', 't', 't', 'l', 'e', '', 'r', 'e', 'd', '-', 'c', 'a', 'p', '', 't', 'o', '', 'h', 'e', 'r', '', 'm', 'o', 't', 'h', 'e', 'r', ':', '', 'a', 'n', 'd', ' ', 'G', 'a', 'V', 'e', '', 'h', 'e', 'r', '', 'h', 'a', 'n', 'd', '', 'o', 'n', '', 'i', 't', '.', ' ', 't', 'h', 'e', '', 'G', 'r', 'a', 'n', 'd', 'm', 'o', 't', 'h', 'e', 'r', '', 'l', 'i', 'V', 'e', 'd', '', 'o', 't', 't', '', 'i', 'n', '', 't', 'h', 'e', '', 'w', 'o', 'o', 'd', ':', '', 'h', 'a', 'l', 'f', '', 'a', '', 'l', 'e', 'a', 'G', 't', 'e', '', 'f', 'r', 'o', 'm', '', 't', 'h', 'e', ' ', 'V', 'i', 'l', 'l', 'a', 'G', 'e', ':', '', 'a', 'n', 'd', '', 'J', 't', 's', 't', '', 'a', 's', '', 'l', 'i', 't', 't', 'l', 'e', '', 'r', 'e', 'd', '-', 'c', 'a', 'p', '', 'e', 'n', 't', 'e', 'r', 'e', 'd', '', 't', 'h', 'e', '', 'w', 'o', 'o', 'd', ':', '', 'a', '', 'w', 'o', 'l', 'f', ' ', 'm', 'e', 't', '', 'h', 'e', 'r', '.', '', '', 'r', 'e', 'd', '-', 'c', 'a', 'p', '', 'd', 'i', 'd', '', 'n', 'o', 't', '', 'k', 'n', 'o', 'w', '', 'w', 'h', 'a', 't', '', 'a', '', 'w', 'i', 'c', 'k', 'e', 'd', '', 'c', 'r', 'e', 'a', 't', 't', 'r', 'e', '', 'h', 'e', '', 'w', 'a', 's', ':', ' ', 'a', 'n', 'd', '', 'w', 'a', 's', '', 'n', 'o', 't', '', 'a', 't', '', 'a', 'l', 'l', '', 'a', 'f', 'r', 'a', 'i', 'd', '', 'o', 'f', '', 'h', 'i', 'm', '.', ' ', 'G', 'o', 'o', 'd', '-', 'd', 'a', 'y', ':', '', 'l', 'i', 't', 't', 'l', 'e', '', 'r', 'e', 'd', '-', 'c', 'a', 'p', ':', '', 's', 'a', 'i', 'd', '', 'h', 'e', '.', ' ', 't', 'h', 'a', 'n', 'k', '', 'y', 'o', 't', '', 'k', 'i', 'n', 'd', 'l', 'y', ':', '', 'w', 'o', 'l', 'f', '.', ' ', 'w', 'h', 'i', 't', 'h', 'e', 'r', '', 'a', 'w', 'a', 'y', '', 's', 'o', '', 'e', 'a', 'r', 'l', 'y', ':', '', 'l', 'i', 't', 't', 'l', 'e', '', 'r', 'e', 'd', '-', 'c', 'a', 'p', '?', ' ', 't', 'o', '', 'm', 'y', '', 'G', 'r', 'a', 'n', 'd', 'm', 'o', 't', 'h', 'e', 'r', '‘', 's', '.', ' ', 'w', 'h', 'a', 't', '', 'h', 'a', 'V', 'e', '', 'y', 'o', 't', '', 'G', 'o', 't', '', 'i', 'n', '', 'y', 'o', 't', 'r', '', 'a', 'p', 'r', 'o', 'n', '?', ' ', 'c', 'a', 'k', 'e', '', 'a', 'n', 'd', '', 'w', 'i', 'n', 'e', '.', '', '', 'y', 'e', 's', 't', 'e', 'r', 'd', 'a', 'y', '', 'w', 'a', 's', '', 'b', 'a', 'k', 'i', 'n', 'G', '-', 'd', 'a', 'y', ':', '', 's', 'o', '', 'p', 'o', 'o', 'r', '', 's', 'i', 'c', 'k', ' ', 'G', 'r', 'a', 'n', 'd', 'm', 'o', 't', 'h', 'e', 'r', '', 'i', 's', '', 't', 'o', '', 'h', 'a', 'V', 'e', '', 's', 'o', 'm', 'e', 't', 'h', 'i', 'n', 'G', '', 'G', 'o', 'o', 'd', ':', '', 't', 'o', '', 'm', 'a', 'k', 'e', '', 'h', 'e', 'r', '', 's', 't', 'r', 'o', 'n', 'G', 'e', 'r', '.', ' ', 'w', 'h', 'e', 'r', 'e', '', 'd', 'o', 'e', 's', '', 'y', 'o', 't', 'r', '', 'G', 'r', 'a', 'n', 'd', 'm', 'o', 't', 'h', 'e', 'r', '', 'l', 'i', 'V', 'e', ':', '', 'l', 'i', 't', 't', 'l', 'e', '', 'r', 'e', 'd', '-', 'c', 'a', 'p', '?', ' ', 'a', '', 'G', 'o', 'o', 'd', '', 'Q', 't', 'a', 'r', 't', 'e', 'r', '', 'o', 'f', '', 'a', '', 'l', 'e', 'a', 'G', 't', 'e', '', 'f', 'a', 'r', 't', 'h', 'e', 'r', '', 'o', 'n', '', 'i', 'n', '', 't', 'h', 'e', '', 'w', 'o', 'o', 'd', '.', '', '', 'h', 'e', 'r', '', 'h', 'o', 't', 's', 'e', ' ', 's', 't', 'a', 'n', 'd', 's', '', 't', 'n', 'd', 'e', 'r', '', 't', 'h', 'e', '', 't', 'h', 'r', 'e', 'e', '', 'l', 'a', 'r', 'G', 'e', '', 'o', 'a', 'k', '-', 't', 'r', 'e', 'e', 's', ':', '', 't', 'h', 'e', '', 'n', 't', 't', '-', 't', 'r', 'e', 'e', 's', '', 'a', 'r', 'e', '', 'J', 't', 's', 't', ' ', 'b', 'e', 'l', 'o', 'w', '.', '', '', 'y', 'o', 't', '', 's', 't', 'r', 'e', 'l', 'y', '', 'm', 't', 's', 't', '', 'k', 'n', 'o', 'w', '', 'i', 't', ':', '', 'r', 'e', 'p', 'l', 'i', 'e', 'd', '', 'l', 'i', 't', 't', 'l', 'e', '', 'r', 'e', 'd', '-', 'c', 'a', 'p', '.', ' ', 't', 'h', 'e', '', 'w', 'o', 'l', 'f', '', 't', 'h', 'o', 't', 'G', 'h', 't', '', 't', 'o', '', 'h', 'i', 'm', 's', 'e', 'l', 'f', ':', '', 'w', 'h', 'a', 't', '', 'a', '', 't', 'e', 'n', 'd', 'e', 'r', '', 'y', 'o', 't', 'n', 'G', '', 'c', 'r', 'e', 'a', 't', 't', 'r', 'e', '.', '', '', 'w', 'h', 'a', 't', '', 'a', ' ', 'n', 'i', 'c', 'e', '', 'p', 'l', 't', 'm', 'p', '', 'm', 'o', 't', 't', 'h', 'f', 't', 'l', ':', '', 's', 'h', 'e', '', 'w', 'i', 'l', 'l', '', 'b', 'e', '', 'b', 'e', 't', 't', 'e', 'r', '', 't', 'o', '', 'e', 'a', 't', '', 't', 'h', 'a', 'n', '', 't', 'h', 'e', '', 'o', 'l', 'd', ' ', 'w', 'o', 'm', 'a', 'n', '.', '', '', 'i', '', 'm', 't', 's', 't', '', 'a', 'c', 't', '', 'c', 'r', 'a', 'f', 't', 'i', 'l', 'y', ':', '', 's', 'o', '', 'a', 's', '', 't', 'o', '', 'c', 'a', 't', 'c', 'h', '', 'b', 'o', 't', 'h', '.', '', '', 's', 'o', '', 'h', 'e', '', 'w', 'a', 'l', 'k', 'e', 'd', ' ', 'f', 'o', 'r', '', 'a', '', 's', 'h', 'o', 'r', 't', '', 't', 'i', 'm', 'e', '', 'b', 'y', '', 't', 'h', 'e', '', 's', 'i', 'd', 'e', '', 'o', 'f', '', 'l', 'i', 't', 't', 'l', 'e', '', 'r', 'e', 'd', '-', 'c', 'a', 'p', ':', '', 'a', 'n', 'd', '', 't', 'h', 'e', 'n', '', 'h', 'e', ' ', 's', 'a', 'i', 'd', ':', '', 's', 'e', 'e', '', 'l', 'i', 't', 't', 'l', 'e', '', 'r', 'e', 'd', '-', 'c', 'a', 'p', ':', '', 'h', 'o', 'w', '', 'p', 'r', 'e', 't', 't', 'y', '', 't', 'h', 'e', '', 'f', 'l', 'o', 'w', 'e', 'r', 's', '', 'a', 'r', 'e', '', 'a', 'b', 'o', 't', 't', '', 'h', 'e', 'r', 'e', '.', ' ', 'w', 'h', 'y', '', 'd', 'o', '', 'y', 'o', 't', '', 'n', 'o', 't', '', 'l', 'o', 'o', 'k', '', 'r', 'o', 't', 'n', 'd', '.', '', '', 'i', '', 'b', 'e', 'l', 'i', 'e', 'V', 'e', ':', '', 't', 'o', 'o', ':', '', 't', 'h', 'a', 't', '', 'y', 'o', 't', '', 'd', 'o', '', 'n', 'o', 't', ' ', 'h', 'e', 'a', 'r', '', 'h', 'o', 'w', '', 's', 'w', 'e', 'e', 't', 'l', 'y', '', 't', 'h', 'e', '', 'l', 'i', 't', 't', 'l', 'e', '', 'b', 'i', 'r', 'd', 's', '', 'a', 'r', 'e', '', 's', 'i', 'n', 'G', 'i', 'n', 'G', '.', '', '', 'y', 'o', 't', '', 'w', 'a', 'l', 'k', '', 'G', 'r', 'a', 'V', 'e', 'l', 'y', ' ', 'a', 'l', 'o', 'n', 'G', '', 'a', 's', '', 'i', 'f', '', 'y', 'o', 't', '', 'w', 'e', 'r', 'e', '', 'G', 'o', 'i', 'n', 'G', '', 't', 'o', '', 's', 'c', 'h', 'o', 'o', 'l', ':', '', 'w', 'h', 'i', 'l', 'e', '', 'e', 'V', 'e', 'r', 'y', 't', 'h', 'i', 'n', 'G', '', 'e', 'l', 's', 'e', '', 'o', 't', 't', ' ', 'h', 'e', 'r', 'e', '', 'i', 'n', '', 't', 'h', 'e', '', 'w', 'o', 'o', 'd', '', 'i', 's', '', 'm', 'e', 'r', 'r', 'y', '.', ' ', 'l', 'i', 't', 't', 'l', 'e', '', 'r', 'e', 'd', '-', 'c', 'a', 'p', '', 'r', 'a', 'i', 's', 'e', 'd', '', 'h', 'e', 'r', '', 'e', 'y', 'e', 's', ':', '', 'a', 'n', 'd', '', 'w', 'h', 'e', 'n', '', 's', 'h', 'e', '', 's', 'a', 'w', '', 't', 'h', 'e', '', 's', 't', 'n', 'b', 'e', 'a', 'm', 's', ' ', 'd', 'a', 'n', 'c', 'i', 'n', 'G', '', 'h', 'e', 'r', 'e', '', 'a', 'n', 'd', '', 't', 'h', 'e', 'r', 'e', '', 't', 'h', 'r', 'o', 't', 'G', 'h', '', 't', 'h', 'e', '', 't', 'r', 'e', 'e', 's', ':', '', 'a', 'n', 'd', '', 'p', 'r', 'e', 't', 't', 'y', '', 'f', 'l', 'o', 'w', 'e', 'r', 's', ' ', 'G', 'r', 'o', 'w', 'i', 'n', 'G', '', 'e', 'V', 'e', 'r', 'y', 'w', 'h', 'e', 'r', 'e', ':', '', 's', 'h', 'e', '', 't', 'h', 'o', 't', 'G', 'h', 't', ':', '', 's', 't', 'p', 'p', 'o', 's', 'e', '', 'i', '', 't', 'a', 'k', 'e', '', 'G', 'r', 'a', 'n', 'd', 'm', 'o', 't', 'h', 'e', 'r', '', 'a', ' ', 'f', 'r', 'e', 's', 'h', '', 'n', 'o', 's', 'e', 'G', 'a', 'y', '.', '', '', 't', 'h', 'a', 't', '', 'w', 'o', 't', 'l', 'd', '', 'p', 'l', 'e', 'a', 's', 'e', '', 'h', 'e', 'r', '', 't', 'o', 'o', '.', '', '', 'i', 't', '', 'i', 's', '', 's', 'o', '', 'e', 'a', 'r', 'l', 'y', '', 'i', 'n', '', 't', 'h', 'e', ' ', 'd', 'a', 'y', '', 't', 'h', 'a', 't', '', 'i', '', 's', 'h', 'a', 'l', 'l', '', 's', 't', 'i', 'l', 'l', '', 'G', 'e', 't', '', 't', 'h', 'e', 'r', 'e', '', 'i', 'n', '', 'G', 'o', 'o', 'd', '', 't', 'i', 'm', 'e', '.', '', '', 'a', 'n', 'd', '', 's', 'o', '', 's', 'h', 'e', '', 'r', 'a', 'n', ' ', 'f', 'r', 'o', 'm', '', 't', 'h', 'e', '', 'p', 'a', 't', 'h', '', 'i', 'n', 't', 'o', '', 't', 'h', 'e', '', 'w', 'o', 'o', 'd', '', 't', 'o', '', 'l', 'o', 'o', 'k', '', 'f', 'o', 'r', '', 'f', 'l', 'o', 'w', 'e', 'r', 's', '.', '', '', 'a', 'n', 'd', '', 'w', 'h', 'e', 'n', 'e', 'V', 'e', 'r', ' ', 's', 'h', 'e', '', 'h', 'a', 'd', '', 'p', 'i', 'c', 'k', 'e', 'd', '', 'o', 'n', 'e', ':', '', 's', 'h', 'e', '', 'f', 'a', 'n', 'c', 'i', 'e', 'd', '', 't', 'h', 'a', 't', '', 's', 'h', 'e', '', 's', 'a', 'w', '', 'a', '', 's', 't', 'i', 'l', 'l', '', 'p', 'r', 'e', 't', 't', 'i', 'e', 'r', '', 'o', 'n', 'e', ' ', 'f', 'a', 'r', 't', 'h', 'e', 'r', '', 'o', 'n', ':', '', 'a', 'n', 'd', '', 'r', 'a', 'n', '', 'a', 'f', 't', 'e', 'r', '', 'i', 't', ':', '', 'a', 'n', 'd', '', 's', 'o', '', 'G', 'o', 't', '', 'd', 'e', 'e', 'p', 'e', 'r', '', 'a', 'n', 'd', '', 'd', 'e', 'e', 'p', 'e', 'r', '', 'i', 'n', 't', 'o', ' ', 't', 'h', 'e', '', 'w', 'o', 'o', 'd', '.', ' ', 'm', 'e', 'a', 'n', 'w', 'h', 'i', 'l', 'e', '', 't', 'h', 'e', '', 'w', 'o', 'l', 'f', '', 'r', 'a', 'n', '', 's', 't', 'r', 'a', 'i', 'G', 'h', 't', '', 't', 'o', '', 't', 'h', 'e', '', 'G', 'r', 'a', 'n', 'd', 'm', 'o', 't', 'h', 'e', 'r', '‘', 's', '', 'h', 'o', 't', 's', 'e', '', 'a', 'n', 'd', ' ', 'k', 'n', 'o', 'c', 'k', 'e', 'd', '', 'a', 't', '', 't', 'h', 'e', '', 'd', 'o', 'o', 'r', '.', ' ', 'w', 'h', 'o', '', 'i', 's', '', 't', 'h', 'e', 'r', 'e', '?', ' ', 'l', 'i', 't', 't', 'l', 'e', '', 'r', 'e', 'd', '-', 'c', 'a', 'p', ':', '', 'r', 'e', 'p', 'l', 'i', 'e', 'd', '', 't', 'h', 'e', '', 'w', 'o', 'l', 'f', '.', '', '', 's', 'h', 'e', '', 'i', 's', '', 'b', 'r', 'i', 'n', 'G', 'i', 'n', 'G', '', 'c', 'a', 'k', 'e', '', 'a', 'n', 'd', ' ', 'w', 'i', 'n', 'e', '.', '', '', 'o', 'p', 'e', 'n', '', 't', 'h', 'e', '', 'd', 'o', 'o', 'r', '.', ' ', 'l', 'i', 'f', 't', '', 't', 'h', 'e', '', 'l', 'a', 't', 'c', 'h', ':', '', 'c', 'a', 'l', 'l', 'e', 'd', '', 'o', 't', 't', '', 't', 'h', 'e', '', 'G', 'r', 'a', 'n', 'd', 'm', 'o', 't', 'h', 'e', 'r', ':', '', 'i', '', 'a', 'm', '', 't', 'o', 'o', '', 'w', 'e', 'a', 'k', ':', '', 'a', 'n', 'd', ' ', 'c', 'a', 'n', 'n', 'o', 't', '', 'G', 'e', 't', '', 't', 'p', '.', ' ', 't', 'h', 'e', '', 'w', 'o', 'l', 'f', '', 'l', 'i', 'f', 't', 'e', 'd', '', 't', 'h', 'e', '', 'l', 'a', 't', 'c', 'h', ':', '', 't', 'h', 'e', '', 'd', 'o', 'o', 'r', '', 's', 'p', 'r', 'a', 'n', 'G', '', 'o', 'p', 'e', 'n', ':', '', 'a', 'n', 'd', '', 'w', 'i', 't', 'h', 'o', 't', 't', ' ', 's', 'a', 'y', 'i', 'n', 'G', '', 'a', '', 'w', 'o', 'r', 'd', '', 'h', 'e', '', 'w', 'e', 'n', 't', '', 's', 't', 'r', 'a', 'i', 'G', 'h', 't', '', 't', 'o', '', 't', 'h', 'e', '', 'G', 'r', 'a', 'n', 'd', 'm', 'o', 't', 'h', 'e', 'r', '‘', 's', '', 'b', 'e', 'd', ':', '', 'a', 'n', 'd', ' ', 'd', 'e', 'V', 'o', 't', 'r', 'e', 'd', '', 'h', 'e', 'r', '.', '', '', 't', 'h', 'e', 'n', '', 'h', 'e', '', 'p', 't', 't', '', 'o', 'n', '', 'h', 'e', 'r', '', 'c', 'l', 'o', 't', 'h', 'e', 's', ':', '', 'd', 'r', 'e', 's', 's', 'e', 'd', '', 'h', 'i', 'm', 's', 'e', 'l', 'f', '', 'i', 'n', ' ', 'h', 'e', 'r', '', 'c', 'a', 'p', ':', '', 'l', 'a', 'i', 'd', '', 'h', 'i', 'm', 's', 'e', 'l', 'f', '', 'i', 'n', '', 'b', 'e', 'd', '', 'a', 'n', 'd', '', 'd', 'r', 'e', 'w', '', 't', 'h', 'e', '', 'c', 't', 'r', 't', 'a', 'i', 'n', 's', '.', ' ', 'l', 'i', 't', 't', 'l', 'e', '', 'r', 'e', 'd', '-', 'c', 'a', 'p', ':', '', 'h', 'o', 'w', 'e', 'V', 'e', 'r', ':', '', 'h', 'a', 'd', '', 'b', 'e', 'e', 'n', '', 'r', 't', 'n', 'n', 'i', 'n', 'G', '', 'a', 'b', 'o', 't', 't', '', 'p', 'i', 'c', 'k', 'i', 'n', 'G', '', 'f', 'l', 'o', 'w', 'e', 'r', 's', ':', ' ', 'a', 'n', 'd', '', 'w', 'h', 'e', 'n', '', 's', 'h', 'e', '', 'h', 'a', 'd', '', 'G', 'a', 't', 'h', 'e', 'r', 'e', 'd', '', 's', 'o', '', 'm', 'a', 'n', 'y', '', 't', 'h', 'a', 't', '', 's', 'h', 'e', '', 'c', 'o', 't', 'l', 'd', '', 'c', 'a', 'r', 'r', 'y', ' ', 'n', 'o', '', 'm', 'o', 'r', 'e', ':', '', 's', 'h', 'e', '', 'r', 'e', 'm', 'e', 'm', 'b', 'e', 'r', 'e', 'd', '', 'h', 'e', 'r', '', 'G', 'r', 'a', 'n', 'd', 'm', 'o', 't', 'h', 'e', 'r', ':', '', 'a', 'n', 'd', '', 's', 'e', 't', '', 'o', 't', 't', '', 'o', 'n', '', 't', 'h', 'e', ' ', 'w', 'a', 'y', '', 't', 'o', '', 'h', 'e', 'r', '.', ' ', 's', 'h', 'e', '', 'w', 'a', 's', '', 's', 't', 'r', 'p', 'r', 'i', 's', 'e', 'd', '', 't', 'o', '', 'f', 'i', 'n', 'd', '', 't', 'h', 'e', '', 'c', 'o', 't', 't', 'a', 'G', 'e', '-', 'd', 'o', 'o', 'r', '', 's', 't', 'a', 'n', 'd', 'i', 'n', 'G', '', 'o', 'p', 'e', 'n', ':', '', 'a', 'n', 'd', ' ', 'w', 'h', 'e', 'n', '', 's', 'h', 'e', '', 'w', 'e', 'n', 't', '', 'i', 'n', 't', 'o', '', 't', 'h', 'e', '', 'r', 'o', 'o', 'm', ':', '', 's', 'h', 'e', '', 'h', 'a', 'd', '', 's', 't', 'c', 'h', '', 'a', '', 's', 't', 'r', 'a', 'n', 'G', 'e', '', 'f', 'e', 'e', 'l', 'i', 'n', 'G', '', 't', 'h', 'a', 't', ' ', 's', 'h', 'e', '', 's', 'a', 'i', 'd', '', 't', 'o', '', 'h', 'e', 'r', 's', 'e', 'l', 'f', ':', '', 'o', 'h', '', 'd', 'e', 'a', 'r', ':', '', 'h', 'o', 'w', '', 't', 'n', 'e', 'a', 's', 'y', '', 'i', '', 'f', 'e', 'e', 'l', '', 't', 'o', '-', 'd', 'a', 'y', ':', '', 'a', 'n', 'd', '', 'a', 't', ' ', 'o', 't', 'h', 'e', 'r', '', 't', 'i', 'm', 'e', 's', '', 'i', '', 'l', 'i', 'k', 'e', '', 'b', 'e', 'i', 'n', 'G', '', 'w', 'i', 't', 'h', '', 'G', 'r', 'a', 'n', 'd', 'm', 'o', 't', 'h', 'e', 'r', '', 's', 'o', '', 'm', 't', 'c', 'h', '.', '', '', 's', 'h', 'e', '', 'c', 'a', 'l', 'l', 'e', 'd', ' ', 'o', 't', 't', ':', '', 'G', 'o', 'o', 'd', '', 'm', 'o', 'r', 'n', 'i', 'n', 'G', ':', '', 'b', 't', 't', '', 'r', 'e', 'c', 'e', 'i', 'V', 'e', 'd', '', 'n', 'o', '', 'a', 'n', 's', 'w', 'e', 'r', '.', '', '', 's', 'o', '', 's', 'h', 'e', '', 'w', 'e', 'n', 't', '', 't', 'o', '', 't', 'h', 'e', ' ', 'b', 'e', 'd', '', 'a', 'n', 'd', '', 'd', 'r', 'e', 'w', '', 'b', 'a', 'c', 'k', '', 't', 'h', 'e', '', 'c', 't', 'r', 't', 'a', 'i', 'n', 's', '.', '', '', 't', 'h', 'e', 'r', 'e', '', 'l', 'a', 'y', '', 'h', 'e', 'r', '', 'G', 'r', 'a', 'n', 'd', 'm', 'o', 't', 'h', 'e', 'r', '', 'w', 'i', 't', 'h', ' ', 'h', 'e', 'r', '', 'c', 'a', 'p', '', 'p', 't', 'l', 'l', 'e', 'd', '', 'f', 'a', 'r', '', 'o', 'V', 'e', 'r', '', 'h', 'e', 'r', '', 'f', 'a', 'c', 'e', ':', '', 'a', 'n', 'd', '', 'l', 'o', 'o', 'k', 'i', 'n', 'G', '', 'V', 'e', 'r', 'y', '', 's', 't', 'r', 'a', 'n', 'G', 'e', '.', ' ', 'o', 'h', ':', '', 'G', 'r', 'a', 'n', 'd', 'm', 'o', 't', 'h', 'e', 'r', ':', '', 's', 'h', 'e', '', 's', 'a', 'i', 'd', ':', '', 'w', 'h', 'a', 't', '', 'b', 'i', 'G', '', 'e', 'a', 'r', 's', '', 'y', 'o', 't', '', 'h', 'a', 'V', 'e', '.', ' ', 't', 'h', 'e', '', 'b', 'e', 't', 't', 'e', 'r', '', 't', 'o', '', 'h', 'e', 'a', 'r', '', 'y', 'o', 't', '', 'w', 'i', 't', 'h', ':', '', 'm', 'y', '', 'c', 'h', 'i', 'l', 'd', ':', '', 'w', 'a', 's', '', 't', 'h', 'e', '', 'r', 'e', 'p', 'l', 'y', '.', ' ', 'b', 't', 't', ':', '', 'G', 'r', 'a', 'n', 'd', 'm', 'o', 't', 'h', 'e', 'r', ':', '', 'w', 'h', 'a', 't', '', 'b', 'i', 'G', '', 'e', 'y', 'e', 's', '', 'y', 'o', 't', '', 'h', 'a', 'V', 'e', ':', '', 's', 'h', 'e', '', 's', 'a', 'i', 'd', '.', ' ', 't', 'h', 'e', '', 'b', 'e', 't', 't', 'e', 'r', '', 't', 'o', '', 's', 'e', 'e', '', 'y', 'o', 't', '', 'w', 'i', 't', 'h', ':', '', 'm', 'y', '', 'd', 'e', 'a', 'r', '.', ' ', 'b', 't', 't', ':', '', 'G', 'r', 'a', 'n', 'd', 'm', 'o', 't', 'h', 'e', 'r', ':', '', 'w', 'h', 'a', 't', '', 'l', 'a', 'r', 'G', 'e', '', 'h', 'a', 'n', 'd', 's', '', 'y', 'o', 't', '', 'h', 'a', 'V', 'e', '.', ' ', 't', 'h', 'e', '', 'b', 'e', 't', 't', 'e', 'r', '', 't', 'o', '', 'h', 't', 'G', '', 'y', 'o', 't', '', 'w', 'i', 't', 'h', '.', ' ', 'o', 'h', ':', '', 'b', 't', 't', ':', '', 'G', 'r', 'a', 'n', 'd', 'm', 'o', 't', 'h', 'e', 'r', ':', '', 'w', 'h', 'a', 't', '', 'a', '', 't', 'e', 'r', 'r', 'i', 'b', 'l', 'e', '', 'b', 'i', 'G', '', 'm', 'o', 't', 't', 'h', '', 'y', 'o', 't', '', 'h', 'a', 'V', 'e', '.', ' ', 't', 'h', 'e', '', 'b', 'e', 't', 't', 'e', 'r', '', 't', 'o', '', 'e', 'a', 't', '', 'y', 'o', 't', '', 'w', 'i', 't', 'h', '.', ' ', 'a', 'n', 'd', '', 's', 'c', 'a', 'r', 'c', 'e', 'l', 'y', '', 'h', 'a', 'd', '', 't', 'h', 'e', '', 'w', 'o', 'l', 'f', '', 's', 'a', 'i', 'd', '', 't', 'h', 'i', 's', ':', '', 't', 'h', 'a', 'n', '', 'w', 'i', 't', 'h', '', 'o', 'n', 'e', '', 'b', 'o', 't', 'n', 'd', '', 'h', 'e', '', 'w', 'a', 's', ' ', 'o', 't', 't', '', 'o', 'f', '', 'b', 'e', 'd', '', 'a', 'n', 'd', '', 's', 'w', 'a', 'l', 'l', 'o', 'w', 'e', 'd', '', 't', 'p', '', 'r', 'e', 'd', '-', 'c', 'a', 'p', '.', ' ', 'w', 'h', 'e', 'n', '', 't', 'h', 'e', '', 'w', 'o', 'l', 'f', '', 'h', 'a', 'd', '', 'a', 'p', 'p', 'e', 'a', 's', 'e', 'd', '', 'h', 'i', 's', '', 'a', 'p', 'p', 'e', 't', 'i', 't', 'e', ':', '', 'h', 'e', '', 'l', 'a', 'y', '', 'd', 'o', 'w', 'n', '', 'a', 'G', 'a', 'i', 'n', '', 'i', 'n', ' ', 't', 'h', 'e', '', 'b', 'e', 'd', ':', '', 'f', 'e', 'l', 'l', '', 'a', 's', 'l', 'e', 'e', 'p', '', 'a', 'n', 'd', '', 'b', 'e', 'G', 'a', 'n', '', 't', 'o', '', 's', 'n', 'o', 'r', 'e', '', 'V', 'e', 'r', 'y', '', 'l', 'o', 't', 'd', '.', '', '', 't', 'h', 'e', ' ', 'h', 't', 'n', 't', 's', 'm', 'a', 'n', '', 'w', 'a', 's', '', 'J', 't', 's', 't', '', 'p', 'a', 's', 's', 'i', 'n', 'G', '', 't', 'h', 'e', '', 'h', 'o', 't', 's', 'e', ':', '', 'a', 'n', 'd', '', 't', 'h', 'o', 't', 'G', 'h', 't', '', 't', 'o', '', 'h', 'i', 'm', 's', 'e', 'l', 'f', ':', '', 'h', 'o', 'w', ' ', 't', 'h', 'e', '', 'o', 'l', 'd', '', 'w', 'o', 'm', 'a', 'n', '', 'i', 's', '', 's', 'n', 'o', 'r', 'i', 'n', 'G', '.', '', '', 'i', '', 'm', 't', 's', 't', '', 'J', 't', 's', 't', '', 's', 'e', 'e', '', 'i', 'f', '', 's', 'h', 'e', '', 'w', 'a', 'n', 't', 's', '', 'a', 'n', 'y', 't', 'h', 'i', 'n', 'G', '.', ' ', 's', 'o', '', 'h', 'e', '', 'w', 'e', 'n', 't', '', 'i', 'n', 't', 'o', '', 't', 'h', 'e', '', 'r', 'o', 'o', 'm', ':', '', 'a', 'n', 'd', '', 'w', 'h', 'e', 'n', '', 'h', 'e', '', 'c', 'a', 'm', 'e', '', 't', 'o', '', 't', 'h', 'e', '', 'b', 'e', 'd', ':', '', 'h', 'e', '', 's', 'a', 'w', ' ', 't', 'h', 'a', 't', '', 't', 'h', 'e', '', 'w', 'o', 'l', 'f', '', 'w', 'a', 's', '', 'l', 'y', 'i', 'n', 'G', '', 'i', 'n', '', 'i', 't', '.', '', '', 'd', 'o', '', 'i', '', 'f', 'i', 'n', 'd', '', 'y', 'o', 't', '', 'h', 'e', 'r', 'e', ':', '', 'y', 'o', 't', '', 'o', 'l', 'd', ' ', 's', 'i', 'n', 'n', 'e', 'r', ':', '', 's', 'a', 'i', 'd', '', 'h', 'e', '.', '', '', 'i', '', 'h', 'a', 'V', 'e', '', 'l', 'o', 'n', 'G', '', 's', 'o', 't', 'G', 'h', 't', '', 'y', 'o', 't', '.', '', '', 't', 'h', 'e', 'n', '', 'J', 't', 's', 't', '', 'a', 's', '', 'h', 'e', '', 'w', 'a', 's', '', 'G', 'o', 'i', 'n', 'G', ' ', 't', 'o', '', 'f', 'i', 'r', 'e', '', 'a', 't', '', 'h', 'i', 'm', ':', '', 'i', 't', '', 'o', 'c', 'c', 't', 'r', 'r', 'e', 'd', '', 't', 'o', '', 'h', 'i', 'm', '', 't', 'h', 'a', 't', '', 't', 'h', 'e', '', 'w', 'o', 'l', 'f', '', 'm', 'i', 'G', 'h', 't', '', 'h', 'a', 'V', 'e', ' ', 'd', 'e', 'V', 'o', 't', 'r', 'e', 'd', '', 't', 'h', 'e', '', 'G', 'r', 'a', 'n', 'd', 'm', 'o', 't', 'h', 'e', 'r', ':', '', 'a', 'n', 'd', '', 't', 'h', 'a', 't', '', 's', 'h', 'e', '', 'm', 'i', 'G', 'h', 't', '', 's', 't', 'i', 'l', 'l', '', 'b', 'e', '', 's', 'a', 'V', 'e', 'd', ':', '', 's', 'o', ' ', 'h', 'e', '', 'd', 'i', 'd', '', 'n', 'o', 't', '', 'f', 'i', 'r', 'e', ':', '', 'b', 't', 't', '', 't', 'o', 'o', 'k', '', 'a', '', 'p', 'a', 'i', 'r', '', 'o', 'f', '', 's', 'c', 'i', 's', 's', 'o', 'r', 's', ':', '', 'a', 'n', 'd', '', 'b', 'e', 'G', 'a', 'n', '', 't', 'o', '', 'c', 't', 't', ' ', 'o', 'p', 'e', 'n', '', 't', 'h', 'e', '', 's', 't', 'o', 'm', 'a', 'c', 'h', '', 'o', 'f', '', 't', 'h', 'e', '', 's', 'l', 'e', 'e', 'p', 'i', 'n', 'G', '', 'w', 'o', 'l', 'f', '.', '', '', 'w', 'h', 'e', 'n', '', 'h', 'e', '', 'h', 'a', 'd', '', 'm', 'a', 'd', 'e', '', 't', 'w', 'o', ' ', 's', 'n', 'i', 'p', 's', ':', '', 'h', 'e', '', 's', 'a', 'w', '', 't', 'h', 'e', '', 'l', 'i', 't', 't', 'l', 'e', '', 'r', 'e', 'd', '-', 'c', 'a']
    #FinalJoint Array once all values are converted to alphabets
    jointbyteArr = "".join(new_byteArr)
    print(jointbyteArr)


    #Frequency Analysis
    encrypted_message = jointbyteArr
    stored_letters = {}
    for char in encrypted_message:
        if char not in stored_letters:
            stored_letters[char] = 1
        else:
            stored_letters[char] += 1

    print(stored_letters,'\n', len(stored_letters))

    # alphabet = ''.join(string.ascii_lowercase + string.punctuation)

    # alphabet = '''abcdefghijklmnopqrstuvwxyz!"'+,-.:; '''
    solution = jointbyteArr

    payload = {'cookie': data['cookie'], 'solution': solution}
    print("[DEBUG] Submitted solution is:")
    print(json.dumps(payload, indent=4, separators=(',', ': ')))
    r = requests.post(url + 'solutions/substitution', headers=headers, data=json.dumps(payload))
    print("[DEBUG] Obtained response: %s" % r.text)


def resolveotpChallenge():
    """
        Solution of otp challenge
    """
    url = "http://{}:{}/".format(IP, PORT)
    headers = {'Content-Type': 'application/json'}

    r = requests.get(url + 'challenges/otp')
    data = r.json()
    #print("[DEBUG] Obtained challenge ciphertext: %s with len %d" % (data['challenge'], len(data['challenge'])))

    # TODO: Add a solution here (conversion from hex to ascii will reveal that the result is in a human readable format)
    a = data['challenge'][2:]
    c = b.unhexlify(a)
    c = c.decode("ASCII")
    plaint_text = "Student ID (1000000) gets (0) points"
    cipher_text = c
    print("1.", cipher_text)
    print("2", plaint_text)
    key = xorString(plaint_text, cipher_text)
    print('3', key, 'is of len', len(key))
    new_plaintext = "Student ID (1006523) gets (6) points"
    new_ciphertext = xorString(new_plaintext, key)
    print('4', new_ciphertext, ' of length ', len(new_ciphertext))
    hex_ciphertext = (new_ciphertext.encode('utf-8')).hex()
    print('5', hex_ciphertext, 'in hex is of len', len(hex_ciphertext))

    payload = {'cookie': data['cookie'], 'solution': hex_ciphertext}
    print("[DEBUG] Submitted solution is:")
    print(json.dumps(payload, indent=4, separators=(',', ': ')))
    r = requests.post(url + 'solutions/otp', headers=headers, data=json.dumps(payload))
    print("[DEBUG] Obtained response: %s" % r.text)


def parseArgs():
    """
        Function for arguments parsing
    """
    aparser = argparse.ArgumentParser(
        description='Script demonstrates breaking of simple ciphers: Caesar, Substitution cipher, and OTP.',
        formatter_class=argparse.RawTextHelpFormatter)
    aparser.add_argument('--port', required=True, metavar='PORT', help='Port of challenge/response server.')
    aparser.add_argument('--ip', required=True, metavar='PORT', help='Port of challenge/response server.')
    aparser.add_argument("--mode", required=True, choices=['p', 'c', 's', 'o'], help="p => demonstrates hexadecimal encoding challenge.\
                         \nc => demonstrates breaking of the Caesar cipher.\
                         \ns => demonstrates breaking of the Substitution cipher.\
                         \no => demonstrates breaking of the OTP cipher.")
    args = aparser.parse_args()

    return args


def main():
    args = parseArgs()

    global IP
    IP = args.ip

    global PORT
    PORT = args.port

    if args.mode == "o":
        resolveotpChallenge()
    elif args.mode == "p":
        resolvePlainChallenge()
    elif args.mode == "c":
        resolveCaesarChallenge()
    elif args.mode == "s":
        resolvesubstitutionChallenge()


if __name__ == '__main__':
    main()