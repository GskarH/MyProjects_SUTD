import pandas as pd

android = pd.read_csv("malware-0,1.csv")
android = android.drop(['binderTransaction', 'cpuUser', 'cpuOther', 'memActive', 'memInactive', 'memMapped', 'memFreePages', 'permissions'], axis = 1)

tp = tn = fp = fn = 0
ac = pr = rc = 0.00

#function returns predicted result as per logic drawn from J48 decision tree model

def predictedResult(binderTotalDeath,binderTotalNodes,cpuSystem):
    if(binderTotalDeath > 802):
        if (binderTotalDeath > 878):
            return 0
        else:
            if (binderTotalNodes > 1317):
                if(binderTotalDeath > 815):
                    return 1
                else:
                    if(cpuSystem > 22):
                        return 0
                    else:
                        return 1
            else:
                return 0
    else:
        if(binderTotalDeath > 395):
            return 1
        else:
            return 0

#looping through predictResult for each row in android list

for i in range(len(android)):
    result = 0
    result = predictedResult(android.binderTotalDeath[i],android.binderTotalNodes[i],android.cpuSystem[i])
    if(result == android.classification[i] == 1):
        tp=tp+1
    elif(result == android.classification[i] == 0):
        tn=tn+1
    elif(result==1 & android.classification[i]==0):
        fp=fp+1
    else:
        fn=fn+1

# print("TP:" + str(tp) + "  FP:" + str(fp) + "  FN:" + str(fn) + "  TN:" + str(tn))
# print(len(android))

ac = ((tp + tn) / len(android))*100
pr = tp / (tp + fp)
rc = tp / (tp + fn)

print("Accuracy :", ac,"%")
print("Precision :", pr)
print("Recall :", rc)