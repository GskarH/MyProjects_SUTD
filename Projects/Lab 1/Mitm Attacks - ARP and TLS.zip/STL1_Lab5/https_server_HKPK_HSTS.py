from flask import Flask, url_for, request, jsonify
from flask_secure_headers.core import Secure_Headers
from functools import wraps
import json
import ssl
import socket
import os

import ssl

context = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
context.load_cert_chain('cert.pem' , 'key.pem')

if socket.gethostname() == "mssd-labs":
    os.chdir("/data/5/")

sh = Secure_Headers()

sh.update({'CSP':{'script-src':['self','code.jquery.com']}})
sh.update({'HPKP':{'pins':[{'sha256':'MUQSeDP2NwTHMR5IKOG1fMZ3qGqdcVFSBmHe77jxqSU='}],'max-age':30}})

sh.update({'HSTS':{'max-age':1,'includeSubDomains':True,'preload':False}})

app = Flask(__name__)

user=''

shadow={'admin':'l4sT_L4b', 'guest':'password'}

def check_auth(username, password):
    if username in shadow and shadow[username]==password:
        global user
        user=username
        return username
    else:
        return False

def authenticate():
    message = {'message': "Authenticate."}
    resp = jsonify(message)

    resp.status_code = 401
    resp.headers['WWW-Authenticate'] = 'Basic realm="Example"'

    return resp

def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.authorization
        if not auth: 
            return authenticate()
        user=check_auth(auth.username, auth.password)
        if not user:
            return authenticate()        
        return f(*args, **kwargs)

    return decorated

mdb={}

@app.route('/messages')
@sh.wrapper()
@requires_auth
def api_messages():
    if user in mdb:
        return jsonify(messages=mdb[user])
    else:
        return jsonify(messages="")

@app.route('/message/<userid>', methods=['POST'])
@sh.wrapper()
@requires_auth
def api_message(userid):
    if not userid in mdb:
        mdb[userid]=[]
    mdb[userid].append("From %s: %s"%(user,request.json['message']))
    print ("Message received from user %s for user %s: %s"%(userid,user,request.json['message']))
    return "Thank you for your message\n"

if __name__ == '__main__':
    app.run(debug=False,host='0.0.0.0',port=443,  ssl_context = context, threaded = True)
